# encoding: utf-8

require 'nokogiri'
require 'open-uri'

class KinopoiskScrapper

  KINOPOISK_URL = 'https://www.kinopoisk.ru/top/lists/1/filtr/all/sort/order/perpage/200/'

  def self.films_from_site(number)
    number = 200 if number > 200

    html = open_url(KINOPOISK_URL)
    page = Nokogiri::HTML.parse(html)
    html.close

    data = page.css('tr.js-film-list-item>td.news').first(number - 1)
    FilmLib.new(prepare_films(data))
  end

  def self.open_url(url)
    open(url)
  end

  def self.prepare_films(data)
    data.map do |div|
      args = {}
      args[:title] = div.css('a.all').text
      args[:year] = div.css('span').text[/\d+/]
      args[:director] = div.css('a.lined').first.text
      Film.new(args)
    end
  end
end
