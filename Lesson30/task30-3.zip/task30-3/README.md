# What to wear!? 

Program that helps you to select clothes that fits for the current weather, my careless friend. 

# How to use

`ruby main.rb`

## Adding your clothes

To add more types of clothes create a txt file in the `/data/(type_of_clothes)` directory, where: 

- 1st line: type of clothes 
- 2nd line: name of element of clothes.
- 3rd line: two numbers which related to min and max temperature comfort to wear this piece of clothing (1st number - min, 2nd - max).

You can add any types you need.

## Requirements 
 
- ruby 2.6.5 
