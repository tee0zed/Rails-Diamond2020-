# What to wear!? 

Program that helps you to select clothes that fits for the current weather, my careless friend. 

# How to use

`ruby main.rb`

## Adding your clothes

To add more types of clothes create a txt file in the `/data` directory, where: 

- 1st line: type of clothes (currently there are 3: `головной убор`(headwear), `торс`(top), and `обувь`(footwear).
- 2nd line: name of element of clothes.
- 3rd line: two numbers which related to min and max temperature of weather comfort to wear this piece of clothing.

## Requirements 
 
- ruby 2.6.5 
